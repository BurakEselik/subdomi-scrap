# subdomi-scrap

A tool 

## Aim of this tool(subdomi-scrap)

This program takes a valid domain address and gives subdomains of it.


## How to install?

    pip install subdomi-scrap


## How to use?

Open terminal or cmd and then type this commands:

    python subdomi-scrap\sds.py -d domain_address

If you want to more detail for the program just type:

    python subdomi-scrap\sds.py -h

Note: Above codes are belong cmd, if you are using linux probably you know how to use it.


## License

This repository is licensed under the MIT license. 
